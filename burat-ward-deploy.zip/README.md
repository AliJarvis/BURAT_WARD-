# BURAT WARD deployment-ready static prototype

Deploy the repository/folder root as a static site. No build step, database, API key, or visitor-side Python is required.

Routes:
- / -> index.html
- /jillo-sereka/ -> jillo-sereka/index.html

## Netlify
Drag the unzipped folder into https://app.netlify.com/drop, or connect the repository. netlify.toml is included.

## Vercel
Import the folder/repository into Vercel; framework preset: Other. vercel.json is included.

## GitHub Pages
Push these files to the main branch of a GitHub repository, then enable Settings > Pages > Source: GitHub Actions. The included workflow deploys on push.

## Local test
python3 server.py

## Data and privacy
All listings and project records are illustrative. Forms validate locally and neither send nor store data. No official biography, contact details, announcements, or development claims are fabricated.
