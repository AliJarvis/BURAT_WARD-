from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import os
os.chdir(Path(__file__).resolve().parent)
class H(SimpleHTTPRequestHandler):
 def end_headers(self):
  self.send_header("X-Content-Type-Options","nosniff");self.send_header("Referrer-Policy","no-referrer");super().end_headers()
ThreadingHTTPServer(("0.0.0.0",8000),H).serve_forever()
